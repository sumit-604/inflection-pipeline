# ROLE 7: FORWARD QUADRUPLE TRANSITION CATALYSTS PROTOCOL (FTTCP)

*Companion to Role 1 (Valuation), Role 2 (Investment Thesis), Role 3 (Devil's Advocate), Role 4 (Quarterly Results Review), Role 5 (Concall Analysis), and Role 6 (Annual Report Deep Dive). Every preceding protocol is backward-looking by construction — they measure what HAS happened. FTTCP is the only protocol that explicitly tests whether forward catalysts exist for the transitions that drive shareholder returns. It is the bridge between historical analysis and the forward investment decision, and it runs BEFORE valuation.*

*Version 1.3 | August 2026 | Dhruva Research. This single document replaces BOTH the v1.0 protocol and the v1.1 Quadruple Transition Addendum in full, and supersedes v1.2. Do not use earlier files alongside this one.*

## THE CORE INSIGHT THAT MOTIVATES THIS PROTOCOL

Businesses create wealth for shareholders when FOUR transitions fire together:

1. **Revenue Growth** — topline scaling at meaningful rates
2. **Margin Expansion** — operating profit margins expanding or sustained at peer-leader benchmarks
3. **Cash Conversion** — CFO/PAT moving toward 0.70x+ with debtor days stable or compressing
4. **Capital Efficiency (ROCE)** — return on capital employed rising or sustained at premium levels (>20% asset-light; >18% asset-heavy)

Any subset without the rest is an incomplete transition. Revenue and margin growth without cash conversion is an accounting transition — the P&L looks good but the balance sheet is funding the growth through working capital and debt. Cash conversion and margins without growth is a stagnant compounder. Revenue and cash without margin is a low-quality growth story. And all three P&L transitions firing with flat ROCE is a growing business at a fair multiple — the capital base is growing as fast as the profits. **Only all four firing together produces a real multibagger**, because ROCE expansion is the multiplier on the other three: it is what converts a growing business into a re-rating candidate.

Capital efficiency is a separate dimension because two businesses can have identical margins and cash conversion yet vastly different returns on deployed capital, and because ROCE lags the others — capex deployed today earns returns tomorrow. The fourth transition is therefore OFTEN the missing one in inflection-stage businesses where the other three are firing. Pace Digitek (June 2026) forced this addition: compressing margins but recovering ROCE — the three-transition framework read it as "margin transition negative" and missed that the capital-efficiency transition was firing.

The transition test as a backward-looking filter is necessary but insufficient. Backward tests punish inflection businesses by definition — a company genuinely transitioning will fail backward tests on cash and margins simply because its historical period dominates the average. FTTCP exists to ask, for each transition: **"Is this transition firing forward over the next 3-6 months (12 months for ROCE), and what is the evidence?"** The protocol is most rigorous when the answer is "no, with no catalyst observable" — because the absence of catalyst is itself diagnostic.

## PIPELINE POSITION AND INVOCATION

**FTTCP is a PRE-VALUATION DISCIPLINE GATE, not a post-valuation synthesis.** The enforced sequence:

**Gate 0 + Emerging Moat scan → Role 4 (Results Review, filing numbers) → Role 5 (Concall Analysis, primary transcript) → Role 5.5 (Downstream Signal Identification) → FTTCP (this protocol) → Role 1 (Valuation) → Role 2 (Thesis) → Role 3 (Devil's Advocate) → Notion save.**

Role 1 Pillar 1 cannot be computed without the FTTCP ROCE forward verdict (see PILLAR 1 INTEGRATION below) — the sequencing is structural, not procedural. Role 5.5 (Downstream Signal Identification, defined in Master Project Prompt v3.4) precedes FTTCP because downstream signals are the leading indicators of catalyst firing; forward catalyst analysis in Step 2 must reference identified signals rather than reconstruct them. The Black Rose case is the canonical demonstration: five destination PE iterations were needed when FTTCP ran last; running it first produces the correct answer on the first pass.

Trigger FTTCP with one of:

- "Run FTTCP on [Company]"
- "Forward transition analysis on [Company]" / "Quadruple transition catalyst check on [Company]"
- Before commencing Role 1 on any new workup (mandatory)
- At any quarterly refresh where 3+ monitoring triggers have fired
- Pasting a recent quarterly result + concall with the request to assess forward thesis

When triggered, you MUST execute the protocol below in full sequence. Do not produce a final FTTCP verdict before completing every step — especially Step 2C, which forces probability assessment with evidence.

**Concall Gate rule:** Role 5 on the LATEST concall must precede FTTCP — management commentary on catalysts is a core input, and it must come from the actual transcript, never a pipeline synthesis. If no actual transcript exists, FTTCP runs with that limitation flagged explicitly and confidence materially reduced; do not fabricate forward catalysts from MD&A or presentation narrative.

**Signal Gate rule (v1.3 addition):** Role 5.5 (Downstream Signal Identification, per Master Project Prompt v3.4) must precede FTTCP. Step 2 (Forward Catalyst Analysis) must reference identified Downstream Signals for each transition where an appropriate signal exists. Signals with Monthly or Event-driven cadence feed the 3-6 month window (Revenue, Margin, Cash transitions); Quarterly-cadence signals feed the 12-month window (ROCE transition). A catalyst that cannot be anchored to any Downstream Signal is graded as evidence-thin and its magnitude assessment is capped at MODERATE. If no downstream signals were identifiable at Role 5.5 for this company (i.e., zero external verification exists), FTTCP proceeds but the composite score is capped at DEEP WATCH pending signal identification.

## WHEN THE QUADRUPLE FRAMEWORK APPLIES

**Mandatory** for capital-intensive archetypes: asset-heavy manufacturing, EPC contractors, BOO/infrastructure operators, lending (use the LENDER TRANSITION SET below), capital goods, industrial/cyclical, hybrid annuity-EPC. For these, running FTTCP without the fourth transition systematically misses capital efficiency dynamics that drive 30-50% of total return.

**Default for everything else.** In asset-light businesses ROCE tracks margin closely, but the fourth transition costs little and occasionally flips verdicts. All FTTCP analyses run after this version date use the quadruple framework. Existing three-transition Notion saves are refreshed (not retroactively revised) at the next quarterly cycle.

## THE FAILURE MODES THIS PROTOCOL IS DESIGNED TO PREVENT

- **Treating a backward pass as forward certainty.** A company with all transitions firing over the last 8 quarters is NOT automatically going to continue. New competition, cycle peaks, regulatory changes, or saturated TAM can stall the transitions. Forward catalysts must be examined even when backward looks great.
- **Treating a backward fail as automatic AVOID without testing forward.** An inflection-stage company fails backward metrics by construction. If forward catalysts are strong (regulatory approval just received, capacity just commissioned, new customer signed), the missing transitions may be about to start. Don't auto-AVOID inflections.
- **Confusing management narrative with actual catalysts.** "We will improve working capital" is not a catalyst. "Receivables factoring facility with Yes Bank sanctioned ₹200 Cr, operational from Q2 FY27" is a catalyst. The protocol forces this distinction.
- **Missing the diagnostic value of catalyst absence.** When management has not addressed a missing transition in two consecutive concalls, that absence is more informative than any positive evidence. Either they don't see the problem (governance concern), don't have a plan (capability concern), or are hiding the plan (strategic concern). All three are negative.
- **Confirmation bias toward the existing thesis.** If the Role 2 thesis is BUY, FTTCP should NOT default to "catalysts confirmed." Look for evidence that catalysts are weakening, not strengthening.
- **Mistaking sector tailwinds for company-specific catalysts.** "Industry growing 25%" is sector context — all peers benefit equally. What matters is differential share capture, which requires company-specific evidence.
- **Forgetting the sequence: revenue → margins → cash → ROCE.** Transitions usually fire in this order (ROCE last, because deployed capital earns with a lag). A company missing several transitions rarely fixes them simultaneously; the order of likely improvement should inform the probability assessment.
- **Ignoring promise-vs-delivery history.** If management promised X improvement in past concalls and did not deliver, the current promise on X gets an additional discount. The Role 5 tracker is a forward-looking input.
- **Bucket-gaming the verdict.** Hybrid verdict labels ("STAGNANT-to-STARTING", "RECOVERING-to-FIRING") are BANNED in v1.2 — they enabled constructive-direction promotion when mapping to verdict rules. Each transition receives exactly one defined state; when judgment falls between two states, round DOWN.

## STEP 0 — PRE-FLIGHT (MANDATORY)

### 0A. Context fetch — two variants

**First workup (no Notion page exists yet):** FTTCP runs using the Gate 0 scorecard, EM scan, Role 4 output, and Role 5 output from the current session. Role-1-derived fields (destination PE, prior thesis, prior DA findings) are marked N/A — they do not exist yet, because FTTCP precedes Role 1. The Notion page is created at the end of the full pipeline sequence, not before FTTCP.

**Quarterly refresh (Notion page exists):** Use Notion search → fetch on the company name. Extract and have ready:

- Current Decision Status (BUY NOW / BUY ON DIPS / WATCHLIST / HELD / EXITED / DEPRECATED / AVOID)
- Backward Quadruple Transition baseline (derive if not already in Notion)
- One-line thesis (from Role 2) and Devil's Advocate findings (from Role 3) — especially what the DA said management would evade
- Promoter Verdict and Management Grade (Role 5 credibility ratio)
- Four-pillar destination PE and key valuation outputs from the prior Role 1
- Last 4 quarterly review entries
- Last Role 5 output — including Triggers Evolution and the Promise-vs-Delivery Tracker
- Prior FTTCP entries and their monitoring triggers

### 0B. Verify position status and forward intent

Before framing ANY analysis with position-action language, ALWAYS verify current Notion Decision Status. State explicitly what forward intent FTTCP is testing:

- **BUY / HELD:** does the buy/hold thesis remain forward-valid?
- **WATCHLIST:** upgrade to BUY or maintain?
- **AVOID:** have forward catalysts changed enough to move to WATCHLIST or re-engage?
- **New company:** FTTCP is part of the initial workup, positioned after Role 4/Role 5 and before Roles 1-3.

### 0C. Confirm primary sources are available

| Required input | Available? | Confidence impact if missing |
|---|---|---|
| Latest concall transcript (actual transcript, not Gemini-synthesised) | Yes/No | If missing: FTTCP confidence drops materially; flag prominently |
| Latest quarterly result filing (full notes, not just headlines) | Yes/No | If missing: cannot assess leading indicators |
| Last 3 quarterly results filings (trajectory) | Yes/No | If missing: cannot assess catalyst momentum |
| Latest investor presentation | Yes/No | Lower priority but helpful |
| Recent stock exchange announcements (last 90 days) | Yes/No | Required — orders, board changes, capital raises |
| Latest credit rating report | Yes/No | Required for cash conversion catalyst assessment |
| Peer comparable data (at least one true peer) | Yes/No | Required for benchmark sanity check |

If 3 or more sources are missing, declare FTTCP inconclusive and request additional inputs OR proceed with a declared low-confidence verdict.

### 0D. Define forward window

- Primary window: 3 months (next quarterly result confirms or refutes catalyst)
- Secondary window: 6 months (next 2 quarterly results)
- Extended window: 12 months (annual cycle) — **the PRIMARY window for the ROCE transition**, because capital cycle effects (commissioning, unwind, dilution) take 2-4 quarters to manifest

All probability assessments must reference these windows specifically. "Will the catalyst fire?" without a time window is meaningless.

### 0E. Business type check

State: standard operating business or lending business. Lenders use the LENDER TRANSITION SET in place of the four standard transitions throughout.

## STEP 1 — DOCUMENT THE BACKWARD QUADRUPLE TRANSITION BASELINE

Build these tables FIRST. This is the foundation against which forward catalysts are measured.

### 1A. Revenue Growth Transition (last 8 quarters or last 3 fiscal years)

| Period | Revenue (₹ Cr) | YoY Growth % | QoQ Growth % |
|---|---|---|---|
| Q-7 … Q-current | | | |

**Backward verdict — Revenue Growth:** [FIRING / STAGNANT / DECLINING / VOLATILE]

- **FIRING**: 3-yr revenue CAGR ≥20% AND last 4 quarters show positive YoY growth
- **STAGNANT**: 3-yr CAGR 0-10% OR last 4 quarters mixed
- **DECLINING**: 3-yr CAGR negative OR last 2 quarters negative YoY
- **VOLATILE**: high variance across quarters making the pattern hard to read

### 1B. Margin Expansion Transition

| Period | EBITDA Margin % | Trajectory | Peer benchmark margin % |
|---|---|---|---|
| FY[Y-3] … TTM current | | | |

**Backward verdict — Margin Expansion:** [FIRING / SUSTAINED / COMPRESSING / VOLATILE]

- **FIRING**: margin expansion >300 bps over 2 years AND current margin below peer ceiling (room to grow)
- **SUSTAINED**: margin stable within ±150 bps over 2 years at healthy absolute level (≥peer median)
- **COMPRESSING**: contraction >150 bps over 2 years
- **VOLATILE**: high variance; no clear trend

### 1C. Cash Conversion Transition (THE CRITICAL ONE)

| Period | PAT (₹ Cr) | CFO (₹ Cr) | CFO/PAT | Debtor Days | Net Debt (₹ Cr) |
|---|---|---|---|---|---|
| FY[Y-3] … TTM current | | | | | |

**Backward verdict — Cash Conversion:** [FIRING / IMPROVING / STAGNANT / DETERIORATING]

- **FIRING**: CFO/PAT >0.70x AND debtor days stable or compressing
- **IMPROVING**: CFO/PAT trajectory from <0.50x toward >0.50x over 2 years; debtor days compressing
- **STAGNANT**: CFO/PAT 0.40-0.60x with no clear trend
- **DETERIORATING**: CFO/PAT declining OR debtor days expanding meaningfully

### 1D. ROCE / Capital Efficiency Transition

| Period | ROCE % | Capital Employed (₹ Cr) | EBIT (₹ Cr) | Trajectory Notes |
|---|---|---|---|---|
| FY[Y-3] … TTM current | | | | |

**Backward verdict — ROCE:** [FIRING / SUSTAINED / TEMPORARILY DEPRESSED / DECLINING / STRUCTURALLY LOW]

- **FIRING:** ROCE >25% AND expanding ≥200 bps per year for 2+ years (compounder territory)
- **SUSTAINED:** stable within ±200 bps over 2 years at premium absolute level (>20% asset-light / >18% asset-heavy)
- **TEMPORARILY DEPRESSED:** collapsed >500 bps in the last 12 months but with identifiable temporary causes (IPO equity bloat / capex deployed-not-earning / inventory hedge / WC bulge)
- **DECLINING:** contracting >300 bps over 2 years with no identifiable temporary catalyst for recovery
- **STRUCTURALLY LOW:** below 15% sustained 3+ years (asset-heavy) or <18% (asset-light)

**The critical ROCE judgment — TEMPORARILY DEPRESSED vs DECLINING.** The test is exactly parallel to the cash conversion structural-vs-growth-induced test: **"If the company stopped growing tomorrow, would ROCE recover to historical levels within 18-24 months?"** If YES → TEMPORARILY DEPRESSED (mechanical recovery catalysts likely exist: inventory unwind, receivables collection, capex commissioning, fixed-cost dilution). If NO → DECLINING or STRUCTURALLY LOW; scrutinise forward catalysts aggressively and bias toward the declining verdict. When in doubt, DECLINING — recovering ROCE is more often a story than a reality.

### 1E. Backward Composite

| Transition | Backward Verdict |
|---|---|
| Revenue Growth | |
| Margin Expansion | |
| Cash Conversion | |
| ROCE / Capital Efficiency | |

**"Positive" is defined (v1.2):** positive backward verdicts are **FIRING, SUSTAINED, IMPROVING**. Everything else — STAGNANT, COMPRESSING, DETERIORATING, DECLINING, VOLATILE, TEMPORARILY DEPRESSED, STRUCTURALLY LOW — is NOT positive. Note: TEMPORARILY DEPRESSED is not positive backward; its constructive treatment happens in the FORWARD assessment, which is the whole point of the protocol.

**Backward status:** 4 positive → BACKWARD PASS (Step 2 tests forward continuity) | 3 positive → BACKWARD PARTIAL (Step 2 focuses on whether the missing one can start) | 2 positive → BACKWARD WEAK | 0-1 positive → BACKWARD FAIL (Step 2 tests whether ANY catalysts exist; default toward AVOID).

## STEP 2 — FORWARD CATALYST ANALYSIS PER TRANSITION

For EACH of the four transitions, complete Sections A → B → C → D in sequence. Do not skip ahead to a verdict.

### Section A: Current Trajectory

- Last quarterly result direction (improving / stable / deteriorating vs the previous quarter)
- Single most recent data point and what it signals
- Peer benchmark — leader and median
- Sector-level direction on this transition

### Section B: Catalyst Identification & Evidence

List 3-5 SPECIFIC catalysts that could improve or sustain this transition over the forward window:

| Catalyst | Description (1 sentence) | Evidence Type (📄/🎙️/🔍) | Source quality | What confirms it firing | What kills it |
|---|---|---|---|---|---|

**Critical rules:**

- **A "NONE FOUND" entry is valid and significant.** If management has not addressed this transition in the last 2 concalls AND no specific operational initiative is documented, write "NONE FOUND" with the note "Absence of catalyst is itself significant — see Section C."
- **Evidence types and confidence weights:** 📄 DOCUMENTED (audited filing, exchange announcement, signed contract, regulatory approval) — full confidence. 🎙️ MANAGEMENT CLAIM (concall, presentation, AR commentary) — discount 30-50% depending on track record. 🔍 ANALYST INFERENCE (data patterns, sector logic) — discount 50-70%.
- **Past promise-vs-delivery applies an additional discount.** If management promised X in past concalls and didn't deliver, the current promise on X is additionally discounted 20%. Reference the Role 5 tracker.
- **Sector tailwind alone does not count.** The company-specific catalyst must show how THIS company captures differential share.

**Catalyst categories per transition (not exhaustive):**

*Revenue Growth:* order book/pipeline scale with contract specifics; capacity just commissioned or about to; new product launches with documented customer commitment; geographic/market expansion executed; named customer additions; regulatory approvals unlocking addressable market; acquisition/strategic transaction; demonstrated pricing power; documented market share gain vs peers.

*Margin Expansion:* operating leverage with the specific revenue threshold for the next step; product/customer mix shift toward higher margin; backward integration with commissioning timeline; vendor consolidation or input cost program; pricing actions with implementation date; AMC/recurring revenue mix growth; premiumisation with executed launches; quantified cost reduction program; capacity utilisation improvement at specific levels; R&D maturing into productised offerings.

*Cash Conversion:* named WC discipline program with debtor-day target; customer payment term renegotiation (specific customer + term change); receivables factoring/discounting facility (sanctioned, operational date); AMC/recurring revenue scaling past a % threshold; negative-WC model elements being built (customer advances); inventory reduction program with target days; sustainable payable extension; customer mix shift toward better-paying segments; settlement of disputed/locked-up WC (specific arbitration outcomes); government policy changes affecting payment cycles (primary source).

*ROCE / Capital Efficiency:* working capital unwind with quantified amount; capex commissioning entering revenue phase (capital deployed-not-earning → earning); asset turnover improvement at specific utilisation targets; operating leverage on fixed assets (revenue >20% with capex <5% of revenue); one-time capital-bloat unwind (IPO cash deployment, inventory hedge reversal); margin expansion on a stable capital base; sale of unproductive assets with quantified release; subsidiary/de-merger capital unlocking (InvIT hive-off, separate listing); negative-WC model improvement; productive debt deployment (debt cost below ROCE of deployed assets).

*ROCE counter-catalysts:* a NEW capex cycle starting (fresh capital that won't earn for 12-24 months — the BOO treadmill); acquisitions above intrinsic ROCE; WC growing in tandem with revenue; capital trapped in SPVs without distributions; goodwill bloat; rights issues/QIPs bloating the denominator without near-term EBIT match.

### Section C: Probability Assessment

| Catalyst | P(fires in 0-3m) | P(fires in 3-6m) [ROCE: 0-6m / 6-12m] | If fires, magnitude | Composite (P × magnitude) |
|---|---|---|---|---|

**Probability bands:** HIGH >60% | MODERATE 30-60% | LOW 10-30% | VERY LOW <10%. Use bands, not false precision.

**Magnitude bands:** HIGH — catalyst alone would shift the transition from one verdict band to another | MODERATE — partial improvement without changing band | LOW — observable but small effect.

**Composite transition probability (v1.2 — the formula is defined):**

**Composite P = P(best single catalyst of Moderate+ magnitude) + 10% per additional INDEPENDENT catalyst of Moderate+ magnitude, maximum +20%, hard cap 90%.**

- "Independent" means the catalysts do not share a failure mode. Two catalysts both depending on the same plant commissioning are ONE catalyst for this purpose.
- Low-magnitude catalysts are recorded but never add to the composite.
- The 90% cap is deliberate: no 3-6 month operational forecast in Indian small-caps justifies more confidence.

### Section D: Per-Transition Forward Verdict

| Field | Value |
|---|---|
| Backward verdict (from Step 1) | |
| Catalyst strength | Strong / Moderate / Weak / None |
| Forward probability (3-6m; 12m for ROCE) | % |
| **Forward verdict** | FIRING / STARTING (ROCE: RECOVERING) / STAGNANT / DECLINING |

**Forward verdict mapping (v1.2 — hybrid labels BANNED; round down when between states):**

- Forward probability >60% AND catalyst strength ≥ Moderate AND backward verdict positive → **FIRING**
- Forward probability >40% with at least one Moderate catalyst, recovery/start not yet confirmed in reported numbers → **STARTING** (ROCE-domain equivalent: **RECOVERING** — they are the same state)
- Forward probability 20-40% → **STAGNANT**
- Forward probability <20% (or going the wrong way) → **DECLINING**

Note the discipline this imposes on ROCE: even at >60% probability with Strong catalysts, a TEMPORARILY DEPRESSED backward verdict yields forward RECOVERING (not FIRING) until the recovery is confirmed in reported numbers — at which point it becomes FIRING. "RECOVERING-to-FIRING" and "STAGNANT-to-STARTING" are hybrid labels and no longer exist.

## STEP 3 — FORWARD QUADRUPLE TRANSITION SCORECARD

| Transition | Backward Verdict | Catalyst Strength | Forward Probability | Forward Verdict | Score |
|---|---|---|---|---|---|
| Revenue Growth | | | 3-6m % | | |
| Margin Expansion | | | 3-6m % | | |
| Cash Conversion | | | 3-6m % | | |
| ROCE / Capital Efficiency | | | 12m % | | |
| | | | | **COMPOSITE** | **/8** |

## STEP 4 — SCORED VERDICT SYSTEM (v1.2 — replaces the enumerated rules tables of v1.0 and v1.1)

**Transition scores:**

| Forward Verdict | Score |
|---|---|
| FIRING | +2 |
| STARTING / RECOVERING | +1 |
| STAGNANT | 0 |
| DECLINING | −1 |

**Composite Score = sum across all four transitions (range −4 to +8).**

| Composite Score | Position Decision |
|---|---|
| 7-8 | **STRONG BUY-candidate** — high conviction; MEDIUM-LARGE sizing if other gates clear |
| 5-6 | **BUY-candidate** — standard conviction; SMALL-MEDIUM sizing |
| 4 | **DEEP WATCH leaning BUY-ON-DIPS** — small starter defensible with strict entry zone |
| 3 | **DEEP WATCH** — wait for confirmation |
| 1-2 | **DEEP WATCH leaning AVOID** — extreme margin of safety required |
| ≤0 | **AVOID / Hard AVOID** — no further analytical resources until triggers fire |

**Overriding cap — the Kernex principle:** any single transition with forward verdict DECLINING AND catalyst strength NONE caps the composite verdict at DEEP WATCH regardless of the score. The most important diagnostic in the protocol — a transition going the wrong way with no observable catalyst — cannot be averaged away by strength elsewhere.

**TRIM/REDUCE rule (retained):** all four transitions FIRING backward + 2 or more with declining forward catalyst strength → TRIM/REDUCE, independent of the score. Backward looks good but forward is weakening — peak quality cycle.

**Override conditions (unchanged):** the mechanical verdict may be overridden ONLY when an override-worthy specific catalyst exists (binding acquisition announcement, regulatory monopoly award), it is documented in Notion with explicit reasoning, and it is re-validated at the next quarterly review. "Strong management" and "great sector" are not override conditions.

## LENDER TRANSITION SET (MANDATORY FOR BANKS, NBFCs, MFIs, HFCs)

CFO/PAT, debtor days, and ROCE are meaningless for lending businesses. The four transitions are REDEFINED:

| # | Lender Transition | FIRING threshold (indicative) | Replaces |
|---|---|---|---|
| 1 | AUM / disbursement growth | AUM CAGR ≥20% with disbursements accelerating | Revenue Growth |
| 2 | NIM / spread | NIM stable or expanding at ≥ peer median; cost of funds trajectory favourable | Margin Expansion |
| 3 | **Asset quality (THE CRITICAL ONE)** | Credit costs within guided band 4+ quarters; GNPA stable/declining; collection efficiency ≥98% | Cash Conversion |
| 4 | RoA / RoE trajectory | RoA ≥ archetype benchmark (MFI ~3%, NBFC ~2.5%, bank ~1.2%) and rising or sustained | ROCE |

- Transition 3 inherits ALL rules that applied to cash conversion — including: absence of management commentary on deteriorating asset quality across 2+ concalls is a negative diagnostic; DECLINING with no catalyst triggers the Step 4 verdict cap.
- Catalyst categories for lender Transition 3: provisioning cycle completion, restructured book runoff, state-specific stress normalisation (MFI), collection infrastructure investment, portfolio mix shift toward secured.
- Data source: Role 4 v1.2 Steps 1L and 5L. Pillar interaction: the Role 1 Asset-Quality Multiplier (Section 1B v3.3 Pillar 2L) must be consistent with this transition's verdict; Pillar 1 for lenders uses ROE.

## STEP 5 — MONITORING TRIGGERS (90-180 DAYS)

| # | Trigger | Threshold | Time Horizon | What it would change in FTTCP |
|---|---|---|---|---|
| 1-8+ | | | | |

**Requirements:** each trigger SPECIFIC and MEASURABLE (not "improved performance" but "EBITDA margin >28% for 2 consecutive quarters"); each with a time horizon; each with an explicit change-condition for the FTTCP verdict; minimum 5, ideally 8-10; cover ALL FOUR transitions (even FIRING ones can reverse); include at least one trigger that tests catalyst absence (e.g., "no mention of WC initiative in next concall = catalyst remains absent → verdict unchanged").

**Re-engagement rule:** if at any quarterly review 3+ monitoring triggers fire favourably AND the previously missing transition shows directional improvement, re-run FTTCP fully. If the missing transition's forward probability moves from <30% to >50%, the position decision may upgrade by one band (AVOID → DEEP WATCH, DEEP WATCH → WATCHLIST, WATCHLIST → BUY-candidate).

## PILLAR 1 INTEGRATION — SOLE AUTHORITY AND SINGLE-CREDIT (v1.2)

### The FTTCP ROCE forward verdict is the SOLE authority for Role 1 Pillar 1 ROCE selection

Role 1's former standalone trajectory-adjustment rule is DELETED. This table is the only mapping:

| FTTCP ROCE Forward Verdict | Pillar 1 ROCE Used |
|---|---|
| FIRING | Current ROCE |
| RECOVERING, probability >60% with Strong catalysts | Midpoint of current and FY[Y+2] expected ROCE |
| RECOVERING, probability 40-60% | 60/40 weighted average of current and FY[Y+2] |
| STAGNANT | Current ROCE |
| DECLINING | FY[Y+1] expected ROCE (lower bound) |

This structurally enforces FTTCP-first: Pillar 1 literally cannot be computed without the verdict.

### Single-credit rule

ROCE recovery is credited in **Pillar 1 (via the table above) OR the Strategic Premium (+1x/+2x ROCE re-rating optionality) — NEVER BOTH.** Default: Pillar 1. The Strategic Premium route is permitted only when the ROCE verdict is STAGNANT or FIRING (no forward uplift entered Pillar 1) yet archetype-supported re-rating optionality genuinely exists. The Section 1B worksheet must state: "ROCE recovery credited via: [Pillar 1 / Strategic Premium / not credited]."

**ROCE re-rating premium is archetype-dependent:** asset-light recovering to ROCE >25% → +2x; asset-heavy recovering to >20% → +1x; BOO/infrastructure treadmill (ROCE cycles, doesn't expand) → 0x.

**Shared-catalyst flag:** if the same catalyst (e.g., capex commissioning) drives both the Pillar 1 forward ROCE and the Pillar 3 Growth Premium, this is permitted (the premiums measure different things) but must be flagged "SHARED CATALYST" so Role 3 stress-tests the single point of failure.

### SOTP rule for hybrid annuity-EPC businesses (Pillar 2 recalibration)

For businesses with material BOO/Ind AS 116 finance-lease components, do NOT apply the Cash Multiplier penalty to the BOO portion — structural cash lag is the BUSINESS MODEL there, not a quality defect, and punishing it twice is double-counting. Instead: EPC/manufacturing/telecom portion → standard four-pillar with cash multiplier; BOO/annuity portion → InvIT-style multiple (10-14x EV/EBITDA per counterparty quality and equity IRR vs cost of capital); blended destination = weighted average. The sector cap is likewise blended (pure EPC 20x; BOO/InvIT-equivalent 14-16x; manufacturing 25-30x; revenue-weighted).

### Sector Cap and the Category-Break Override (v1.3 addition)

The sector cap in Section 1B of the Master Project Prompt (v3.4 onward) is the absolute ceiling on destination PE under normal conditions. The Category-Break Override is the narrow, evidence-heavy mechanism by which the sector cap can be raised for a company that is establishing a genuinely new category — not merely growing fast within an existing one.

**The distinction that motivates the override.** A company operating inside an established sector, however excellent, sits under the sector cap because the market has already learned how to value the sector. The cap embeds the sector's structural ceiling on capital intensity, cyclicality, cash conversion, and competitive dynamics. But when a company is the first-mover in a new category — Bloom-Energy-hotbox economics for Mtar in India, an exclusive Vertiv-Nvidia GB200 liquid-cooling partnership for Aeroflex, a molecular-glue CDMO capability for Sai — the sector reference itself is stale. The historical sector cap is priced against businesses that do not have this position. Applying it mechanically to the category-break case understates fair value.

The override is deliberately narrow. It is not a general escape hatch for high-growth stories, high-P/E darlings, or exciting narratives. It is not triggered by any single condition, and it is never automatic.

**Qualifying conditions (all four must hold — narrow gating).**

| # | Condition | What qualifies |
|---|---|---|
| 1 | **First-mover in a new category, not fastest grower in an old one** | Category is either newly created, newly accessible in the geography, or newly economic (technology maturity threshold crossed). Reference-checked by naming the specific market that did not exist as a purchasable good three years ago. |
| 2 | **Explicit customer or partner commitment** | Named binding contract, framework agreement, exclusive distributor tie-up, or equivalent — not letter of intent, not MOU, not concall guidance. Signed and disclosed. |
| 3 | **Capacity or capex commissioning timeline** | Documented plant, line, or module commissioning schedule that maps the category buildout to a specific quarter or half. Not "in due course." |
| 4 | **Competitor absence** | Documented evidence that no listed competitor of comparable scale is producing at the same specification or serving the same customer. Absence is proved by direct search of exports data, filings, and customer disclosures — not by an assertion. |

If ANY of these four is missing or thin, the override does NOT apply and the sector cap holds. When in doubt, deny the override; sector cap is the safe default.

**Evidence bar (three independent primary sources).**

Every override invocation must cite THREE independent primary sources of documented type (📄), not two, and not two documented + one management claim (🎙️). The canonical trio:

- Customer commitment (contract, framework agreement, or exclusive tie-up — as filed with the exchange or referenced in customer's own filings)
- Capex commissioning timeline (audited AR CWIP note, exchange announcement, or contractor disclosure that establishes a dated commissioning path)
- Competitor absence (independent — cross-check via exports data, RBI/DGCI&S/customs sources, or independent industry report — never inferred solely from the company's own narrative)

Second-tier sources (rating agency, industry association, sector-focused independent research) may substitute for the competitor-absence source when direct verification is impossible, but not for either of the first two. Management concalls and investor presentations count as ZERO sources for override purposes; they cannot be one of the three.

**Magnitude cap: +40% maximum above the sector cap, no exceptions.**

The category-break-adjusted cap = min(Sector Cap × 1.40, 45x absolute ceiling regardless of sector). The 45x absolute ceiling exists to prevent Platform/SaaS-style 60x+ multiples from bleeding into other sectors through override rationalisation. Worked examples of what the +40% cap permits:

| Sector | Baseline Sector Cap | Post-Override Cap (×1.40) | Applies to |
|---|---|---|---|
| Data centers / cloud infrastructure (capital-heavy) | 30x | 42x | Mtar (Bloom-Energy hotbox category), Aeroflex (Vertiv-Nvidia liquid-cooling) |
| Pharma / CDMO | 38x | 45x (absolute ceiling binds) | Sai (molecular-glue and K-RAS CDMO capability) |
| Specialty chemicals | 35x | 45x (absolute ceiling binds) | reserved for genuine category-break cases |
| Cables / Industrial products | 25x | 35x | reserved |
| EPC / Civil construction | 20x | 28x | reserved |

The override is applied to the sector cap step of the Four-Pillar Summary Calculation (Section 1B row G in v3.4). The Raw × 1.25 UA multiplier is applied FIRST; the override then raises the cap against which the UA-adjusted raw PE is compared. Ordering: **Final Destination PE = min( Raw × UA_multiplier, Sector Cap × Override_multiplier_if_qualified )**, with the whole expression floored at zero and capped at 45x.

**Sunset clause: 4 quarters, no automatic renewal.**

Every override entered in Notion carries an explicit expiry date exactly four quarters forward from the invocation date. On expiry, the override lapses and the sector cap reverts unless the analyst has re-documented — using fresh primary sources within the current cycle — that all four qualifying conditions still hold. Sunset is not a renewal option; it is a forced re-underwriting. Renewal without fresh evidence is treated as an error and unwound at the next quarterly refresh.

Sunset applies even if the underlying category has "obviously" stuck. This is deliberate. The discipline is the point.

**Notion documentation requirement.**

Every override must be logged in Notion COMPANIES MASTER with these fields, prepended to the Key Notes audit trail:

- Date invoked
- Sunset date (invocation date + 12 months, quarter-end)
- Qualifying conditions 1-4, each stated in one sentence
- Three primary sources, each cited with URL or document reference
- Baseline sector cap and override-adjusted cap
- Any Devil's Advocate reservation (Role 3 must have stress-tested the override before it is committed)

An override entered without complete Notion documentation is not valid and is reversed at the next quarterly review.

**Devil's Advocate stress-test requirement.**

Role 3 (Devil's Advocate) must include an explicit test of the override:

- What would remove condition 1 (category becomes commoditised, competitor emerges, technology alternative displaces)?
- What would remove condition 2 (customer terminates contract, partnership dilutes, exclusivity ends)?
- What would remove condition 3 (capex delayed, commissioning slips, first line under-runs specification)?
- What would remove condition 4 (peer enters the category, competitor secures parallel customer, upstream substitute matures)?

If any of these tests produces a plausible 12-month scenario that removes the condition, the override is either denied at inception or entered with a shortened sunset (2 quarters).

**What the override does NOT do.**

It does not raise the ROCE base multiple. It does not enlarge the cash multiplier. It does not raise the growth premium. It does not extend to the RRM track (which has its own durability and governance mechanics). It touches ONE thing only: the sector cap that the raw destination PE is capped against.

The override is the pressure-release valve for the Bloom/Vertiv/molecular-glue class of cases that phreak-style category-defining bets create. It is not a general upward adjustment. Everyone will be tempted to invoke it for the next exciting story. The gating conditions and sunset are the discipline that keep it rare.

## EMPIRICAL CONTEXT — ROCE-LED RE-RATING

ROCE expansion has historically been the single most powerful re-rating driver in Indian small-caps:

| Company | Period | ROCE Trajectory | PE Re-rating | Annualised Return |
|---|---|---|---|---|
| Polycab India | FY18-22 | 17% → 27% | 18x → 45x | ~55% |
| KEI Industries | FY18-22 | 18% → 28% | 16x → 50x | ~60% |
| APL Apollo Tubes | FY17-22 | 22% → 35% | 18x → 50x | ~70% |
| Astral Pipes | FY16-21 | 25% → 30% | 30x → 80x | ~50% |
| Persistent Systems | FY19-22 | 18% → 28% | 20x → 50x | ~65% |
| Tata Elxsi | FY18-22 | 28% → 38% | 25x → 80x | ~75% |
| Deepak Nitrite | FY18-22 | 22% → 35% | 18x → 45x | ~60% |

Capital-heavy caveat — the pattern is muted but real: Power Mech FY17-22 ROCE 18-22% oscillating, PE 8x → 15x; KNR 10x → 18x; PNC 9x → 16x; KEC 12x → 22x. For capital-heavy businesses ROCE oscillates within a ~5-point band because new capex deployment temporarily depresses it; the re-rating is ~2x rather than 3x.

**ENDPOINT-BIAS ANNOTATION (v1.2):** endpoint multiples in these tables reflect FY21-22 peak-cycle conditions. For planning purposes, use the LOWER BOUND of the 1.5-2.5x re-rating estimate. The +1x/+2x re-rating optionality premium sizing already reflects this conservatism and is unchanged.

## STEP 6 — SAVE AND ROLL FORWARD

### 6A. Save FTTCP output to Notion

The complete analysis goes into the Notion company page as a new section titled "FTTCP — [Date]": backward baseline (Step 1E), per-transition catalyst tables (Step 2B), forward scorecard with scores (Step 3), composite score and verdict with cap state (Step 4), monitoring triggers (Step 5), and the Pillar 1 handoff line ("ROCE verdict: ___ → Pillar 1 ROCE: ___%; recovery credited via: ___"). New entries are added each run; old entries are never deleted — they are the audit trail of how forward expectations evolved.

### 6B. Update Decision Status if the FTTCP verdict differs

If the verdict implies a Decision Status change, update the row property in the Notion COMPANIES MASTER database immediately, and prepend a date-prefixed entry to Key Notes.

### 6C. Quarterly review cycle

After every quarterly result + concall cycle: Q result → Role 4 → Role 5 → FTTCP refresh → (Roles 1-3 refresh if any pillar input changed) → Update Notion. Mandatory every quarter for HELD positions; after each result for WATCHLIST and DEEP WATCH; annually or on trigger-fire for AVOID.

## METHODOLOGICAL DISCIPLINE — RULES THAT MUST NEVER BE VIOLATED

1. **No catalyst counts as a catalyst.** Write "NONE FOUND" when accurate. Don't fabricate catalysts to fill the table.
2. **Sector tailwinds are not company catalysts.** Company-specific differential share capture is required.
3. **Management narratives discounted appropriately.** 30-50% discount on pure management claims without operational evidence.
4. **Past delivery discounts current promises.** Apply the Role 5 Promise-vs-Delivery Tracker discount.
5. **Two missing transitions almost never fix simultaneously.** Sequence: revenue → margins → cash → ROCE. A company missing 2-3 transitions with hopes of simultaneous firing is almost always wrong.
6. **The absence of management commentary on a missing transition is the loudest signal.** Two consecutive silent concalls is decisive — capability gap, governance issue, or strategic concealment.
7. **Confirmation bias check.** Before finalising: "If I had no prior position or thesis, would I reach the same forward conclusion?" If the answer requires the existing position, restart Step 2.
8. **Concall Gate mandatory.** No FTTCP without Role 5 on an actual transcript. If unavailable, declare reduced confidence — never fabricate catalysts from secondary narrative.
9. **Probability humility.** Bands, not false precision. Composite cap 90%.
10. **The output IS the work product, not the verdict.** A verdict without populated catalyst tables and probability assessments is fraudulent.
11. **ROCE is a 12-month transition, not 3-6 months.** Capital cycle effects manifest over 2-4 quarters; use the extended window as primary for ROCE.
12. **TEMPORARILY DEPRESSED vs DECLINING is the critical ROCE judgment.** Apply the "if growth stopped tomorrow" test rigorously; bias toward DECLINING when in doubt.
13. **The re-rating premium is archetype-dependent.** Full for asset-light crossing compounder ROCE; partial for asset-heavy; none for BOO treadmills.
14. **Hybrid verdict labels are banned; round down.** Each transition gets exactly one defined state; ambiguity resolves conservatively; scores are never promoted to fit a better verdict row (there are no rows — only the sum).
15. **Single-credit for ROCE recovery.** Pillar 1 or Strategic Premium, never both; the choice is stated in writing.

## INTEGRATION WITH OTHER ROLES

| Role | Relationship to FTTCP |
|---|---|
| Gate 0 + Emerging Moat | Backward business quality baseline; Gate 0 Block A (Return on Capital) feeds the ROCE backward verdict |
| Role 1 (Valuation) | The FTTCP ROCE forward verdict is the SOLE authority for Pillar 1 ROCE selection; FTTCP validates the Pillar 2 cash multiplier (or Pillar 2L asset-quality band) against forward reality; the single-credit rule governs the Strategic Premium |
| Role 2 (Thesis) | The thesis must reference the transition status of all four transitions; FTTCP probability-weights the growth triggers |
| Role 3 (Devil's Advocate) | DA challenges the backward thesis; FTTCP challenges the forward thesis; DA must stress-test the ROCE recovery catalysts and any SHARED CATALYST flag |
| Role 4 (Quarterly Review) | Provides the quarterly data feeding Step 1 trajectories and Step 5 triggers; for lenders, Steps 1L/5L feed the lender transition set directly |
| Role 5 (Concall Analysis) | Critical input: management catalyst commentary and the Promise-vs-Delivery discount; silence on capital efficiency over 2+ consecutive concalls = STAGNANT classification |
| Role 6 (AR Deep Dive) | Audited evidence underlying catalyst documentation; AR Phase 2 must include explicit ROCE trajectory analysis |

Full workup sequence:

```
Gate 0 → Emerging Moat scan → Promoter Background Check
              ↓
Sheet 2 deep analysis → Sheet 3 peer comparison
              ↓
Role 4 (Results) → Role 5 (Concall)
              ↓
       Role 7 (FTTCP)  ←— this protocol
              ↓
Role 1 (Valuation) → Role 2 (Thesis) → Role 3 (Devil's Advocate)
              ↓
       Final Notion disposition
```

Quarterly refresh: Role 4 → Role 5 → FTTCP refresh → (Roles 1-3 if pillars changed) → Update Notion.

## WORKED EXAMPLE 1 — KERNEX MICROSYSTEMS (June 2026, three-transition run, rescored under v1.2)

Kernex was assessed in June 2026 with a backward AVOID from Roles 1-3. Concall Gate: NOT CLEARED (no actual transcripts; catalyst analysis relied on AR + presentations + exchange announcements, with confidence flagged).

**Step 1 baseline:** Revenue FIRING (FY24 ₹19.6 Cr → FY25 ₹189.8 Cr → TTM ₹430 Cr) | Margin FIRING at ceiling (−110% → +21.5% → +34.6%; HBL benchmark 33.69%) | Cash DETERIORATING (debtor days 45 → 268; borrowings 4x'd to fund the WC gap).

**Step 2 highlights:** Revenue — strong documented catalysts (CLW loco order with delivery schedule, Kavach 4.0 RDSO approval Oct 2025, BLW/PLW/DFCCIL LoAs); forward verdict FIRING. Margin — moderate catalysts (operating leverage, in-sourcing, test automation) against L1 bidding pressure and 62.69% material costs; forward verdict STAGNANT at peak. Cash — the catalyst search returned **NONE FOUND** across every category: no management commentary on WC in 14 months of disclosures, no factoring facility, no payment term renegotiation; CARE explicitly classifies the WC intensity as structural; the ₹275 Cr CC/BG sanction is the WRONG signal (more debt to fund WC, not less). Forward verdict DECLINING, catalyst strength NONE.

**Step 4 under v1.2 scoring:** Revenue +2, Margin 0, Cash −1 → composite +1 on the three-transition scale → DEEP WATCH leaning AVOID band, AND the Kernex cap engages (DECLINING with catalyst NONE → capped at DEEP WATCH). The final AVOID was set by the promoter/governance veto operating through the hardest-verdict-wins rule — outcome identical to the original run. The protocol's distinct contribution: the AVOID is defensible on a purely forward-looking, governance-independent path (the most important transition is going backwards with no observable catalyst), and it carries defined re-engagement conditions.

**Step 5 monitoring triggers (abridged):** management names a WC plan with timeline in the Q1 FY27 concall; Q1 FY27 debtor days <230; quarterly CFO >₹30 Cr positive; factoring facility announced; AMC >15% of revenue; FY26 auditor opinion unqualified; borrowings below ₹120 Cr without an equity raise. Three or more firing → full FTTCP re-run.

## WORKED EXAMPLE 2 — PACE DIGITEK (June 2026, quadruple run, rescored under v1.2)

The case that forced the fourth transition. Concall Gate CLEARED (Q2-Q4 FY26 transcripts read directly). Notion status before: WATCHLIST/AVOID.

**Step 1 baseline:** Revenue FIRING (3-yr CAGR 59.8%; Q4 FY26 +60.5% YoY) | Margin COMPRESSING (20.6% → 17.2%, −340 bps; guidance walked down) | Cash DETERIORATING (cumulative 3-yr CFO/PAT −1.08x; debtor days 160 → 337) | ROCE TEMPORARILY DEPRESSED (40.85% → 37.89% → 14.30% audited FY26; TTM already recovering to 21.30%; IPO bloat + capex + WC bulge all identified as temporary — the "growth stopped tomorrow" test passes).

**Step 2 ROCE catalysts (abridged):** inventory unwind ₹540 Cr → ₹300 Cr (📄, HIGH); receivables collection with ₹300 Cr already collected Apr-May 2026 (🎙️+📄, MODERATE-HIGH); BOO annuity EBIT commencement (📄 first site commissioned Sep 2025, HIGH); 5+10 GWh capacity earning on installed equipment (📄, HIGH). Counter-catalysts: BOO treadmill re-bloating the capital base; IREDA drawdown adding ₹615 Cr debt; BESS pricing competition. Composite: ~65% probability of ROCE >18% within 12 months, Strong catalyst strength.

**Forward verdicts under v1.2 (hybrids banned, rounded down):** Revenue FIRING (+2). Margin STARTING (+1) — floor defence with moderate contested catalysts. Cash STAGNANT (0) — the old "STAGNANT-to-STARTING" hybrid rounds DOWN. ROCE RECOVERING (+1) — the old "RECOVERING-to-FIRING" hybrid is banned; 65% probability with Strong catalysts still scores as RECOVERING until the recovery is confirmed in reported numbers.

**Step 4:** composite = 2 + 1 + 0 + 1 = **4 → DEEP WATCH leaning BUY-ON-DIPS.** Identical to the v1.1 verdict — but now reached mechanically, with no bucket-mapping argument. (The v1.1 run reached the same answer by promoting both hybrids upward to fit the "2 FIRING + 2 STARTING" row; v1.2 removes that channel and the answer survives, which is the point.)

**Pillar 1 handoff under v1.2:** ROCE verdict RECOVERING at >60% with Strong catalysts → Pillar 1 uses the midpoint of current and FY[Y+2] expected ROCE. **ROCE recovery credited via: Pillar 1.** The +1x strategic ROCE re-rating premium from the v1.1 worked example is therefore WITHDRAWN (single-credit rule) — the v1.1 Section 8 valuation table double-credited the same recovery through both Pillar 1 forward-midpoint and the strategic premium. SOTP treatment of the BOO portion (no cash multiplier penalty; InvIT-style 12.5x EV/EBITDA; blended 17.5x cap) is unchanged.

## CLOSING PRINCIPLE

The single most important contribution of FTTCP is forcing the question: **"Is there a catalyst for what's missing?"** The quadruple framework adds a second question of equal weight: **"Is capital deployed today going to earn returns tomorrow?"**

Backward analysis tells you what has happened. Forward analysis tells you what is likely to happen. Only catalyst analysis tells you WHY something is likely to happen. A business does not transition because investors hope it will; it transitions because specific operational, regulatory, competitive, or strategic catalysts produce specific transitions. And it becomes a multibagger only when the P&L transitions fire while the capital base does not grow proportionally — when ROCE rises with the rest.

FTTCP is the discipline that catches the cases where everything looks good but no catalyst exists to convert good-looking into actually-good, and the cases where everything looks bad backward but forward catalysts are forming. Run before valuation, scored mechanically, with hybrid labels banned and ambiguity rounding down, it is the protocol most resistant to confirmation bias — because it requires evidence of specific catalysts, not narratives, and because its output feeds Pillar 1 rather than rationalising it.

*The Quadruple Transition test, run forward with rigorous catalyst analysis before any valuation, is what separates investing from speculation.*

## VERSION HISTORY

| Version | Date | Changes |
|---|---|---|
| 1.0 | June 2026 | Initial three-transition forward catalyst protocol: probability bands, verdict rules, monitoring trigger structure. Worked example: Kernex Microsystems. |
| 1.1 | 24 June 2026 | Quadruple Transition addendum: ROCE added as fourth co-equal transition, mandatory for capital-intensive archetypes. TEMPORARILY DEPRESSED vs DECLINING test. Pillar 1 forward-ROCE decision table, SOTP rules for hybrid annuity-EPC, ROCE re-rating optionality premium, empirical re-rating tables. Worked example: Pace Digitek. |
| 1.2 | 02 July 2026 | Consolidated into one document (v1.0 + v1.1 merged; both prior files retired). Sequencing corrected to Gate 0 → Role 4 → Role 5 → FTTCP → Roles 1-3 with first-workup/refresh Step 0A variants. FTTCP ROCE verdict made SOLE authority for Pillar 1; Role 1 standalone trajectory rule deleted; single-credit rule for ROCE recovery with shared-catalyst flag; Pace example annotated (strategic +1x withdrawn). Scored verdict system (FIRING +2 / STARTING-RECOVERING +1 / STAGNANT 0 / DECLINING −1, bands −4 to +8) replaces enumerated rules; hybrid labels banned; round-down rule; Kernex cap codified; both worked examples reproduce identical verdicts. Composite probability formula defined (best Moderate+ catalyst +10% per independent Moderate+, max +20%, cap 90%). "Positive" defined for the backward composite. Lender transition set added (AUM growth / NIM / asset quality / RoA-RoE) tied to Role 4 v1.2 Steps 1L-5L and Section 1B v3.3 Pillar 2L. Empirical tables annotated for FY21-22 endpoint bias. |
| 1.3 | 11 August 2026 | Category-Break Override added to the Pillar 1 Integration section as the sole mechanism by which the Section 1B sector cap can be raised. Four qualifying conditions (first-mover in a new category; explicit customer/partner commitment; capex commissioning timeline; competitor absence) — all four must hold. Three-source documented-evidence bar (📄 only for the override; management sources count as zero). Magnitude hard-capped at Sector Cap × 1.40 with 45x absolute ceiling. Sunset clause: 4 quarters, no automatic renewal; forced re-underwriting on expiry. Role 3 stress-test of all four conditions is mandatory before an override is committed. Notion documentation and audit-trail fields specified. Ordering codified: min(Raw × UA, Sector Cap × Override_multiplier). Motivated by category-defining single-partner bets (Mtar/Bloom, Aeroflex/Vertiv, Sai/molecular-glue class) where the sector cap understates fair value; deliberately narrow to prevent general-purpose upward re-rating. Also: Pipeline sequence updated to insert Role 5.5 (Downstream Signal Identification, defined in Master Project Prompt v3.4) between Role 5 (Concall) and FTTCP. Signal Gate rule added: Step 2 Forward Catalyst Analysis must reference identified Downstream Signals; catalyst magnitude assessment is capped at MODERATE where no signal anchor exists; FTTCP composite is capped at DEEP WATCH where no signals were identifiable at Role 5.5. |
